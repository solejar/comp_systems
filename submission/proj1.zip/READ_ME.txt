Hello!

If you would like to compile parts A-D:
make all

If you also want to compile the code used to generate input data:
make all_with_file

Data will be written to the working directory, but example outputs are also saved in the folder "output"

The Spark script is written in Python, and can only be tested if your local machine has PySpark installed.  